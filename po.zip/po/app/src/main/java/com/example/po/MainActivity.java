package com.example.po;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);








        setContentView(R.layout.activity_main);
        ArrayList <pokemon> pokemonpall = new ArrayList<>();
        pokemon n = new pokemon("Bulbasaur",R.drawable.bulbasaurr,200,400,600);
        pokemon y = new pokemon(" Ivysaur",R.drawable.ivysaur,100,600,700);
        pokemon t = new pokemon("Venusaur",R.drawable.venusaurr,300,500,800);

        pokemonpall.add(n);//0
        pokemonpall.add(y);//1
        pokemonpall.add(t);//2

        RecyclerView g = findViewById(R.id.recyclerView);






    }
}